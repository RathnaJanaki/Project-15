# CRM Backend Development

Node.js + Express + MongoDB + JWT CRM API with authentication, customer CRUD, and support case assignment.

## Prerequisites
- Node.js 18+
- MongoDB running locally or a MongoDB Atlas connection string

## Setup
1. Open this folder in VS Code.
2. Run `npm install`.
3. Edit `.env`: set `MONGODB_URI` and a strong random `JWT_SECRET` (at least 32 characters). Never commit `.env`.
4. Start MongoDB if using a local database.
5. Run `npm run dev` or `npm start`.
6. Open `http://localhost:5000/health`.

## Important security notes
- Public registration only creates regular users. It does not allow clients to make themselves admins.
- Customer and case deletion are admin-only. To promote a trusted account for local testing, update that user's `role` to `admin` directly in MongoDB, then log in again.
- For production, restrict CORS origins, use HTTPS, keep secrets in a secure environment manager, and add automated tests and audit logging.

See `docs/API.md` for endpoints and sample request bodies.

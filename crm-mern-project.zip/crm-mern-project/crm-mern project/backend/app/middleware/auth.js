const jwt = require('jsonwebtoken');
const User = require('../models/User');

async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ')) return res.status(401).json({ message: 'Login token தேவை' });
    const token = header.slice(7);
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.userId);
    if (!user) return res.status(401).json({ message: 'பயனர் கிடைக்கவில்லை' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token தவறானது அல்லது காலாவதியானது' });
  }
}

function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ message: 'Admin அனுமதி தேவை' });
  next();
}
module.exports = { authenticate, requireAdmin };

function notFound(req, res, next) {
  res.status(404).json({ message: `Route கிடைக்கவில்லை: ${req.method} ${req.originalUrl}` });
}

function errorHandler(err, req, res, next) {
  console.error(err);
  if (err.name === 'ValidationError') {
    return res.status(400).json({ message: 'தரவு சரிபார்ப்பு தோல்வி', errors: Object.values(err.errors).map(e => e.message) });
  }
  if (err.name === 'CastError') return res.status(400).json({ message: 'தவறான ID format' });
  if (err.code === 11000) return res.status(409).json({ message: 'இந்த email ஏற்கனவே பயன்படுத்தப்படுகிறது' });
  res.status(err.status || 500).json({ message: err.status ? err.message : 'சர்வரில் எதிர்பாராத பிழை' });
}
module.exports = { notFound, errorHandler };

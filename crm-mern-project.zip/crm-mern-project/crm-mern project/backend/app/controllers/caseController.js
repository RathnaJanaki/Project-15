const Case = require('../models/Case');
const Customer = require('../models/Customer');
const User = require('../models/User');

const populateCase = query => query.populate('customer', 'name email phone').populate('assignedTo', 'username email').populate('createdBy', 'username email');

exports.list = async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.priority) filter.priority = req.query.priority;
    if (req.query.customer) filter.customer = req.query.customer;
    if (req.query.assignedTo) filter.assignedTo = req.query.assignedTo;
    const cases = await populateCase(Case.find(filter).sort({ createdAt: -1 }));
    res.json({ count: cases.length, cases });
  } catch (err) { next(err); }
};

exports.getOne = async (req, res, next) => {
  try {
    const supportCase = await populateCase(Case.findById(req.params.id));
    if (!supportCase) return res.status(404).json({ message: 'Case கிடைக்கவில்லை' });
    res.json({ case: supportCase });
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    const { title, customer, description, priority, assignedTo } = req.body;
    if (!title || !customer) return res.status(400).json({ message: 'title மற்றும் customer ID கட்டாயம்' });
    if (!(await Customer.exists({ _id: customer }))) return res.status(400).json({ message: 'Customer ID செல்லுபடியாகவில்லை' });
    if (assignedTo && !(await User.exists({ _id: assignedTo }))) return res.status(400).json({ message: 'Assigned user கிடைக்கவில்லை' });
    const supportCase = await Case.create({ title, customer, description, priority, assignedTo: assignedTo || null, createdBy: req.user._id });
    res.status(201).json({ message: 'Case உருவாக்கப்பட்டது', case: await populateCase(Case.findById(supportCase._id)) });
  } catch (err) { next(err); }
};

exports.update = async (req, res, next) => {
  try {
    const allowed = ['title', 'description', 'priority', 'status', 'assignedTo', 'customer'];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];
    if (updates.customer && !(await Customer.exists({ _id: updates.customer }))) return res.status(400).json({ message: 'Customer ID செல்லுபடியாகவில்லை' });
    if (updates.assignedTo && !(await User.exists({ _id: updates.assignedTo }))) return res.status(400).json({ message: 'Assigned user கிடைக்கவில்லை' });
    const supportCase = await populateCase(Case.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true }));
    if (!supportCase) return res.status(404).json({ message: 'Case கிடைக்கவில்லை' });
    res.json({ message: 'Case புதுப்பிக்கப்பட்டது', case: supportCase });
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    const supportCase = await Case.findByIdAndDelete(req.params.id);
    if (!supportCase) return res.status(404).json({ message: 'Case கிடைக்கவில்லை' });
    res.json({ message: 'Case நீக்கப்பட்டது' });
  } catch (err) { next(err); }
};

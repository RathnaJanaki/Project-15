const Customer = require('../models/Customer');

exports.list = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.search) filter.$or = [
      { name: { $regex: req.query.search, $options: 'i' } },
      { email: { $regex: req.query.search, $options: 'i' } },
      { company: { $regex: req.query.search, $options: 'i' } }
    ];
    const [customers, total] = await Promise.all([
      Customer.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).populate('createdBy', 'username email'),
      Customer.countDocuments(filter)
    ]);
    res.json({ customers, pagination: { total, page, limit, pages: Math.ceil(total / limit) } });
  } catch (err) { next(err); }
};

exports.getOne = async (req, res, next) => {
  try {
    const customer = await Customer.findById(req.params.id).populate('createdBy', 'username email');
    if (!customer) return res.status(404).json({ message: 'Customer கிடைக்கவில்லை' });
    res.json({ customer });
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    if (!req.body.name) return res.status(400).json({ message: 'Customer name கட்டாயம்' });
    const customer = await Customer.create({ ...req.body, createdBy: req.user._id });
    res.status(201).json({ message: 'Customer உருவாக்கப்பட்டது', customer });
  } catch (err) { next(err); }
};

exports.update = async (req, res, next) => {
  try {
    const allowed = ['name', 'email', 'phone', 'company', 'address', 'status'];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];
    const customer = await Customer.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    if (!customer) return res.status(404).json({ message: 'Customer கிடைக்கவில்லை' });
    res.json({ message: 'Customer புதுப்பிக்கப்பட்டது', customer });
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    const customer = await Customer.findByIdAndDelete(req.params.id);
    if (!customer) return res.status(404).json({ message: 'Customer கிடைக்கவில்லை' });
    res.json({ message: 'Customer நீக்கப்பட்டது' });
  } catch (err) { next(err); }
};

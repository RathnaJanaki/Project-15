const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

function createToken(user) {
  return jwt.sign({ userId: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });
}

exports.register = async (req, res, next) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) return res.status(400).json({ message: 'username, email, password கட்டாயம்' });
    if (String(password).length < 8) return res.status(400).json({ message: 'Password குறைந்தது 8 எழுத்துகள் இருக்க வேண்டும்' });
    const normalizedEmail = String(email).trim().toLowerCase();
    if (await User.findOne({ email: normalizedEmail })) return res.status(409).json({ message: 'இந்த email ஏற்கனவே பதிவு செய்யப்பட்டுள்ளது' });
    // Public registration எப்போதும் user role மட்டுமே உருவாக்கும்.
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ username, email: normalizedEmail, passwordHash, role: 'user' });
    res.status(201).json({ message: 'பதிவு வெற்றி', token: createToken(user), user: { id: user._id, username: user.username, email: user.email, role: user.role } });
  } catch (err) { next(err); }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'email மற்றும் password கட்டாயம்' });
    const user = await User.findOne({ email: String(email).trim().toLowerCase() }).select('+passwordHash');
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ message: 'Email அல்லது password தவறு' });
    res.json({ message: 'Login வெற்றி', token: createToken(user), user: { id: user._id, username: user.username, email: user.email, role: user.role } });
  } catch (err) { next(err); }
};

exports.me = async (req, res) => {
  res.json({ user: { id: req.user._id, username: req.user.username, email: req.user.email, role: req.user.role } });
};

const test = require('node:test');
const assert = require('node:assert/strict');

test('basic test runner works', () => {
  assert.equal(2 + 2, 4);
});

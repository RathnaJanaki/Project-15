# CRM Backend API Documentation

Base URL: `http://localhost:5000`

Protected endpoints require header: `Authorization: Bearer <JWT_TOKEN>`.

## Authentication
- `POST /api/auth/register` body: `{ "username": "Demo User", "email": "demo@example.com", "password": "strongpass123" }`
- `POST /api/auth/login` body: `{ "email": "demo@example.com", "password": "strongpass123" }`
- `GET /api/auth/me` authenticated user details.

## Customers (JWT required)
- `GET /api/customers?page=1&limit=10&search=demo&status=active`
- `POST /api/customers` body: `{ "name": "ABC Stores", "email": "contact@abc.example", "phone": "9876543210", "company": "ABC", "address": "Chennai", "status": "lead" }`
- `GET /api/customers/:id`
- `PATCH /api/customers/:id` body can include `name`, `email`, `phone`, `company`, `address`, `status`.
- `DELETE /api/customers/:id` admin only.

## Cases (JWT required)
- `GET /api/cases?status=open&priority=high`
- `POST /api/cases` body: `{ "title": "Payment issue", "description": "Invoice question", "customer": "CUSTOMER_ID", "priority": "high" }`
- `GET /api/cases/:id`
- `PATCH /api/cases/:id` body can include `title`, `description`, `priority`, `status`, `assignedTo`, `customer`.
- `DELETE /api/cases/:id` admin only.

Valid case priorities: `low`, `medium`, `high`, `urgent`.
Valid case statuses: `open`, `in_progress`, `resolved`, `closed`.
Valid customer statuses: `lead`, `active`, `inactive`.

## Error responses
The API uses HTTP 400 for validation errors, 401 for missing/invalid authentication, 403 for insufficient role, 404 for missing resources/routes, 409 for duplicate email and 500 for unexpected server errors.

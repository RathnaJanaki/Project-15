# Enhancing CRM Solutions with MERN Integration

தமிழில் அமைக்கப்பட்ட MERN CRM assignment. இதில் React responsive UI, Express REST API, MongoDB/Mongoose, JWT registration/login, bcrypt password hashing, customer CRUD, search/filter மற்றும் error handling உள்ளன.

## Folder structure
- `backend/` — Express server, MongoDB models, routes, controllers, JWT middleware.
- `frontend/` — React + Vite UI.

## Backend setup
1. Node.js 18+ மற்றும் MongoDB இயங்குவதை உறுதிசெய்யவும்.
2. Terminal: `cd backend`
3. `npm install`
4. `backend/.env.example`-ஐ `.env` என copy செய்து `MONGODB_URI` மற்றும் `JWT_SECRET` values அமைக்கவும். JWT_SECRET குறைந்தது 32 characters ஆக இருக்க வேண்டும்; `.env`-ஐ பகிர வேண்டாம்.
5. `npm run dev`
6. `http://localhost:5000/health` திறந்து சோதிக்கவும்.

## Frontend setup
1. புதிய terminal: `cd frontend`
2. `npm install`
3. `frontend/.env.example`-ஐ `.env` என copy செய்யவும். `VITE_API_URL=http://localhost:5000/api` இருக்க வேண்டும்.
4. `npm run dev`
5. Browser: `http://localhost:5173`

## Testing flow
1. Register மூலம் account உருவாக்கவும்.
2. Login செய்யவும்.
3. Customer form-ல் customer சேர்க்கவும்.
4. Search மற்றும் status filter சோதிக்கவும்.
5. Edit, Delete சோதிக்கவும்.
6. Logout செய்து மீண்டும் login செய்யவும்.

## API endpoints
- `POST /api/auth/register` — username, email, password
- `POST /api/auth/login` — email, password
- `GET /api/auth/me` — Bearer token
- `GET /api/customers` — Bearer token
- `POST /api/customers` — Bearer token
- `GET /api/customers/:id` — Bearer token
- `PATCH /api/customers/:id` — Bearer token
- `DELETE /api/customers/:id` — Bearer token
- `GET /health` — health check

## Screen recording & submission
Windows-ல் `Win + G` அல்லது OBS Studio மூலம் browser-ஐ பதிவு செய்யலாம். Register, Login, customer create, search/filter, edit, delete, logout ஆகியவற்றைக் காட்டவும். Video-வை MP4 ஆக save செய்து Google Classroom-ல் upload செய்யவும். Password, `.env`, JWT secret ஆகியவற்றை video-வில் காட்ட வேண்டாம். Project ZIP-ஐயும் submit செய்யவும்.

## Deployment
Frontend-ஐ Vercel/Netlify, backend-ஐ Render/Railway, database-ஐ MongoDB Atlas-ல் deploy செய்யலாம். `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL`, `VITE_API_URL` environment variables-ஐ deployment settings-ல் அமைக்கவும். Production-க்கு CORS origin-ஐ frontend domain-க்கு கட்டுப்படுத்தவும்.

> இது assignment/demo project. Production பயன்பாட்டிற்கு automated tests, password reset, email verification, stricter security configuration மற்றும் monitoring சேர்க்க பரிந்துரைக்கப்படுகிறது.
